#include <stdio.h>
#include <stdlib.h>

char* intToBinaryString(unsigned int num) {
    unsigned int n;
    char temp[32]; 
    int index, i;

    
    if (num == 0) {
        char *zeroStr = (char*)malloc(2);
        if (!zeroStr) return NULL;
        zeroStr[0] = '0';
        zeroStr[1] = '\0';
        return zeroStr;
    }

    index = 0;
    n = num;

   
    while (n > 0) {
        temp[index++] = (n % 2) + '0';
        n /= 2;
    }

   
    char *binStr = (char*)malloc(index + 1);
    if (!binStr) return NULL;
    binStr[index] = '\0';

   
    for (i = 0; i < index; i++) {
        binStr[i] = temp[index - i - 1];
    }

    return binStr;
}

int main() {
    unsigned int number;
    char *binaryString;

    printf("10������ �Է��ϼ��� : ");
    if (scanf("%u", &number) != 1) {
        printf("���� �Է��ϼ���.\n");
        return 1;
    }

    binaryString = intToBinaryString(number);
    if (!binaryString) {
        printf("���� : �޸� �Ҵ� ����.\n"); 
        return 1;
    }

    printf("2���� �� : %s\n", binaryString);
    free(binaryString);

    return 0;
}

