#include <stdio.h>
#include <stdlib.h>
#include <string.h>


unsigned char binStrToInt(const char* str) {
    unsigned char value = 0;
    int i; 
    for (i = 0; i < 8; i++) {
        if (str[i] != '0' && str[i] != '1') {
            fprintf(stderr, "���� : 0 �Ǵ� 1�� ��� �����մϴ�.\n");
            exit(EXIT_FAILURE);
        }
        value <<= 1;
        if (str[i] == '1') value |= 1;
    }
    return value;
}


void intToBinStr(unsigned char value, char* str) {
    int i;  
    for (i = 7; i >= 0; i--) {
        str[7 - i] = (value & (1 << i)) ? '1' : '0';
    }
    str[8] = '\0';
}


unsigned char subtractBinary(unsigned char A, unsigned char B) {
    return A - B;
}


void readBinary8(char* str) {
    char buffer[100];
    if (!fgets(buffer, sizeof(buffer), stdin)) {
        fprintf(stderr, "�Է� ����\n");
        exit(EXIT_FAILURE);
    }

    
    if (strchr(buffer, '\n') == NULL) {
        int c;
        while ((c = getchar()) != '\n' && c != EOF);
    }

    
    size_t len = strlen(buffer);
    if (len > 0 && buffer[len - 1] == '\n') {
        buffer[len - 1] = '\0';
        len--;
    }

    if (len != 8) {
        fprintf(stderr, "�Է� ����: ��Ȯ�� 8�ڸ� �������� �Է��ϼ���.\n");
        exit(EXIT_FAILURE);
    }

    int i;  
    for (i = 0; i < 8; i++) {
        str[i] = buffer[i];
    }
    str[8] = '\0';
}

int main(void) {
    char aStr[9], bStr[9], resultStr[9];

    printf("ù ��° ������ �Է� (8�ڸ�): ");
    readBinary8(aStr);

    printf("�� ��° ������ �Է� (8�ڸ�): ");
    readBinary8(bStr);

    unsigned char A = binStrToInt(aStr);
    unsigned char B = binStrToInt(bStr);

    if (A < B) {
        fprintf(stderr, "���� : ù ��° ���� �� ��° ������ �۽��ϴ�.\n");
        return EXIT_FAILURE;
    }

    unsigned char result = subtractBinary(A, B);
    intToBinStr(result, resultStr);

    printf("%s - %s = %s\n", aStr, bStr, resultStr);

    return EXIT_SUCCESS;
}
