#include <stdio.h>

int hexCharToInt(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    else if (c >= 'A' && c <= 'F') return 10 + (c - 'A');
    else if (c >= 'a' && c <= 'f') return 10 + (c - 'a');
    else return -1; 
}

int hexToDecimal(const char *hexStr) {
    int result = 0;
    int i = 0;
    int val;

    while (hexStr[i] != '\0') {
        val = hexCharToInt(hexStr[i]);
        if (val == -1) {
            printf("���� : A ~ F���� �Է��ϼ���");
            return -1;
        }
        result = result * 16 + val;
        i++;
    }
    return result;
}

int main() {
    char hexString[20];

    printf("16������ �Է��ϼ��� : ");
    scanf("%s", hexString);

    int decimalValue = hexToDecimal(hexString);
    if (decimalValue != -1) {
        printf("10���� �� : %d\n", decimalValue);
    }

    return 0;
}
