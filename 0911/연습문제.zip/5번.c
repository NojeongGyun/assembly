#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX 1005  


char* addBaseB(const char* num1, const char* num2, int base) {
    int len1 = strlen(num1);
    int len2 = strlen(num2);

    
    char* result = (char*)malloc(MAX);
    if (!result) {
        printf("���� : �޸� �Ҵ� ����\n");
        exit(1);
    }
    result[MAX - 1] = '\0';  

    int carry = 0;
    int i = len1 - 1;
    int j = len2 - 1;
    int k = MAX - 2;  

    while (i >= 0 || j >= 0 || carry) {
        int digit1 = (i >= 0) ? num1[i] - '0' : 0;
        int digit2 = (j >= 0) ? num2[j] - '0' : 0;

        
        if (digit1 >= base || digit2 >= base) {
            printf("���� : ���ڰ� ���� ������ ���\n");
            free(result);
            exit(1);
        }

        int sum = digit1 + digit2 + carry;
        carry = sum / base;
        result[k--] = (sum % base) + '0';

        i--;
        j--;
    }

    
    char* finalResult = strdup(result + k + 1);
    free(result);
    return finalResult;
}

int main() {
    char num1[MAX], num2[MAX];
    int base;

    printf("������ �Է��ϼ��� (2~10): ");
    scanf("%d", &base);

    printf("ù ��° �� �Է�: ");
    scanf("%s", num1);

    printf("�� ��° �� �Է�: ");
    scanf("%s", num2);

    char* sum = addBaseB(num1, num2, base);
    printf("��: %s\n", sum);

    free(sum);  
    return 0;
}
