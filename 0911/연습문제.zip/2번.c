#include <stdio.h>

#define MAX_32BIT_HEX 8  


unsigned int hexCharToInt(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    else if (c >= 'A' && c <= 'F') return 10 + (c - 'A');
    else if (c >= 'a' && c <= 'f') return 10 + (c - 'a');
    else return 0xFFFFFFFF; 
}


unsigned int hex32ToInt(const char *hexStr) {
    unsigned int result = 0;
    int i = 0;
    unsigned int val;

   
    while (hexStr[i] != '\0') i++;
    if (i > MAX_32BIT_HEX) {
        printf("���� : 32��Ʈ�� �Ѱ���ϴ�. \n");
        return 0;
    }

    
    i = 0;
    while (hexStr[i] != '\0') {
        val = hexCharToInt(hexStr[i]);
        if (val == 0xFFFFFFFF) {
            printf("���� : A ~ F���� �Է��ϼ���");
            return 0;
        }
        result = result * 16 + val;
        i++;
    }

    return result;
}

int main() {
    char hexString[20];
     printf("16������ �Է��ϼ��� : ");
    scanf("%s", hexString);

    unsigned int decimalValue = hex32ToInt(hexString);
    if (decimalValue != 0) {
        printf("10������ �� : %u\n", decimalValue);
    }

    return 0;
}
